﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.TabPanel_TabStrip.Controllers
{
    public class OverviewController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
