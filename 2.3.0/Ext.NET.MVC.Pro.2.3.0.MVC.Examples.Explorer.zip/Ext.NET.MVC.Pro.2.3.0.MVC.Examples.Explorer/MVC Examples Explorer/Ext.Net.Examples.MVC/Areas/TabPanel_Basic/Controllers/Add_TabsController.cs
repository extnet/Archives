﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.TabPanel_Basic.Controllers
{
    public class Add_TabsController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
