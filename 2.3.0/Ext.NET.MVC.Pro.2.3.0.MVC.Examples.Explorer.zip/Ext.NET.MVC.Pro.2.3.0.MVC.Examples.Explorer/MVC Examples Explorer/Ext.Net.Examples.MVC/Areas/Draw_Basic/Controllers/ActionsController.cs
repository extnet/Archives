﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Draw_Basic.Controllers
{
	public class ActionsController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		public ActionResult CreateSprite(string button)
		{
			Sprite sprite = new Sprite
			{
				SpriteID = "Sprite1",
				Type = SpriteType.Rect,
				Width = 100,
				Height = 100,
				X = 150,
				Y = 150,
				Fill = "green"
			};

			this.GetCmp<DrawComponent>("Draw1").Add(sprite);
			sprite.Show(true);

			return this.Direct();
		}

		public ActionResult ChangeColor(string button)
		{
			this.GetCmp<DrawComponent>("Draw1").GetSprite("Sprite1").SetAttributes(new SpriteAttributes { Fill = "red" }, true);

			return this.Direct();
		}

		public ActionResult RotateLeft(string button)
		{
			this.GetCmp<DrawComponent>("Draw1").GetSprite("Sprite1").SetAttributes(new SpriteAttributes { Rotate = new RotateAttribute { Degrees = -45 } }, true);

			return this.Direct();
		}

		public ActionResult RotateRight(string button)
		{
			this.GetCmp<DrawComponent>("Draw1").GetSprite("Sprite1").Animate(new AnimConfig
			{
				Duration = 1000,
				To = 
                { 
                    new Ext.Net.Parameter("rotate", "{degrees:0}", ParameterMode.Raw)
                }
			});

			return this.Direct();
		}

		public ActionResult Scaling(string button)
		{
			this.GetCmp<DrawComponent>("Draw1").GetSprite("Sprite1").SetAttributes(new SpriteAttributes { Scale = new ScaleAttribute { X = 2, Y = 2 } }, true);

			return this.Direct();
		}

		public ActionResult Translation(string button)
		{
			this.GetCmp<DrawComponent>("Draw1").GetSprite("Sprite1").SetAttributes(new SpriteAttributes { Translate = new TranslateAttribute { X = -100, Y = -100 } }, true);

			return this.Direct();
		}
	}
}
