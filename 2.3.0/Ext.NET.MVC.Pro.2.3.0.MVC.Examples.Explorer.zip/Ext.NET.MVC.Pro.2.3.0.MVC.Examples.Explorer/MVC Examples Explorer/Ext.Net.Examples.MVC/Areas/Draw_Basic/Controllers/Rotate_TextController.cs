﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Draw_Basic.Controllers
{
    public class Rotate_TextController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
