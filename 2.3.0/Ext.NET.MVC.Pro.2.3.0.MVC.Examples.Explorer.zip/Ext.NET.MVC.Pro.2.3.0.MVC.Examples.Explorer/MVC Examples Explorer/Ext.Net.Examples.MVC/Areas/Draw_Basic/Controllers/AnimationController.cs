﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Draw_Basic.Controllers
{
    public class AnimationController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

		public ActionResult AnimateRect()
        {
            X.GetCmp<DrawComponent>("Draw1").GetGroup("rectangles").Animate(new AnimConfig
            {
                Duration = 1000,
                To = 
                { 
                    new Ext.Net.Parameter("translate", "{x:150}", ParameterMode.Raw)
                }
            });

			return this.Direct();
        }
    }
}
