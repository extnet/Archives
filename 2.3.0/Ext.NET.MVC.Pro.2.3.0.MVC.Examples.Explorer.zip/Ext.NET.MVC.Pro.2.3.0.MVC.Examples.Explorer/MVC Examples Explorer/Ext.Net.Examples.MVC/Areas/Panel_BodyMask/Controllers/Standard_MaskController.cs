﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Panel_BodyMask.Controllers
{
    public class Standard_MaskController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
