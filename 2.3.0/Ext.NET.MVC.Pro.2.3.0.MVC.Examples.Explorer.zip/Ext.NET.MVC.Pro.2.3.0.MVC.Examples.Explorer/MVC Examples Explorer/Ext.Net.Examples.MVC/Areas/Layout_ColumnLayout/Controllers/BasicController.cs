﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Layout_ColumnLayout.Controllers
{
    public class BasicController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
