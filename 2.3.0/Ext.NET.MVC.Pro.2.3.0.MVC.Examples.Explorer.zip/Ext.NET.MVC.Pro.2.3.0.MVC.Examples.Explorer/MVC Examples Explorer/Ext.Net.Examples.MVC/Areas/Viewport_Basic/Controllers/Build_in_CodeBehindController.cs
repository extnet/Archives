﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Viewport_Basic.Controllers
{
    public class Build_in_CodeBehindController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
