﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Window_Basic.Controllers
{
	public class Window_VariationsController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

	}
}