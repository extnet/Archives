﻿using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace Ext.Net.MVC.Examples.Areas.Window_Basic.Controllers
{
	public class Load_External_WebsiteController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

	}
}