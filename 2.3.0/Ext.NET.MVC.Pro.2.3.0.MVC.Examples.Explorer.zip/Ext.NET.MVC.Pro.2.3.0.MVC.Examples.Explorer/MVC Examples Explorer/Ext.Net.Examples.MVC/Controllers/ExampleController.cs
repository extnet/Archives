﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Controllers
{
    public class ExampleController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
 
        public StoreResult LoadFakeChildren()
        {
            NodeCollection nodes = new NodeCollection(false);
 
            for (int index = 1; index < 6; index++)
            {
                Node node = new Node
                {
                    NodeID = index.ToString()
                };
 
                node.CustomAttributes.Add(new ConfigItem
                {
                    Name = "Task",
                    Value = ((index % 2 == 0) ? string.Format("{0} - OK", index) : string.Format("{0} - Fail - Hover me", index)),
                    Mode = ParameterMode.Value
                });
                nodes.Add(node);
            }
 
            return new StoreResult
            {
                Data = nodes.ToJson()
            };
        }
    }
}
