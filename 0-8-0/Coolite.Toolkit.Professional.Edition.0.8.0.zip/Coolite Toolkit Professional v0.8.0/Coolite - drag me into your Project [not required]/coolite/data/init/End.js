
// @source data/init/End.js

if (typeof Sys !== "undefined") { 
    Sys.Application.notifyScriptLoaded();
}