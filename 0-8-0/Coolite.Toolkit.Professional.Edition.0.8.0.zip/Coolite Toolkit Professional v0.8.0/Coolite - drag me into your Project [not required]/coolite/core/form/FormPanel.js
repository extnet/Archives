
// @source core/form/FormPanel.js

Ext.form.FormPanel.override({
    initComponent : function () {
        this.form = this.createForm();

        this.bodyCfg = {
            tag    : "form",
            cls    : this.baseCls + "-body",
            method : this.method || "POST",
            id     : this.formId || Ext.id()
        };
        
        if (this.fileUpload) {
            this.bodyCfg.enctype = "multipart/form-data";
        }

        if (this.isInForm) {
            this.bodyCfg.tag = "div";
        }

        Ext.FormPanel.superclass.initComponent.call(this);

        this.initItems();

        this.addEvents(
            /**
            * @event clientvalidation
            * If the monitorValid config option is true, this event fires repetitively to notify of valid state
            * @param {Ext.form.FormPanel} this
            * @param {Boolean} valid true if the form has passed client-side validation
            */
            "clientvalidation"
        );

        this.relayEvents(this.form, ["beforeaction", "actionfailed", "actioncomplete"]);
    }
});