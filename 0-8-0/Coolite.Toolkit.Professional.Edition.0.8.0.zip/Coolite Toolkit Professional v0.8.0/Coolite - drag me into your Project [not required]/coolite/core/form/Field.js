
// @source core/form/Field.js

Ext.form.Field.override({
    hideWithLabel : true,
    
    setReadOnly   : function (readOnly) {
        if (this.rendered) {
            this.el.dom.setAttribute("readOnly", readOnly);
            this.el.dom.readOnly = readOnly;
        } else {
            this.readOnly = readOnly;
        }
    },
    
    getReadOnly : function () {
        return this.rendered ? this.el.dom.readOnly : this.readOnly;
    },
    
    adjustWidth : function (tag, w) {
	    if (typeof w == "number" && (Ext.isIE6 || !Ext.isStrict) && /input|textarea/i.test(tag) && !this.inEditor) {
		    return w - 3;
	    }
	    return w;
    }
});

Ext.form.Field.prototype.initComponent = Ext.form.Field.prototype.initComponent.createSequence(function () {
    this.on("hide", function () {
        if (this.label && this.hideWithLabel) {

            var parent = this.getActionEl().parent(".x-form-item");
            
            if (!Ext.isEmpty(parent)) {
                parent.addClass("x-hide-" + this.hideMode);
            }                
        }
    });

    this.on("show", function () {
        if (this.label && this.hideWithLabel) {

            var parent = this.getActionEl().parent(".x-form-item");
            
            if (!Ext.isEmpty(parent)) {
                parent.removeClass("x-hide-" + this.hideMode);
            }                 
        }
    });
    
    this.on("render", function () {
        if (!Ext.isEmpty(this.note, false)) {
            this.wrap = this.wrap || this.el.wrap();                
            
            var beforeEl = undefined;
            
            if (this.noteAlign == "top") {
                this.noteEl = Ext.DomHelper.insertBefore(this.wrap, { cls : "x-field-note " + (this.noteCls || ""), html : this.note });
                return;
            }
            
            this.noteEl = this.wrap.createChild({ cls : "x-field-note " + (this.noteCls || ""), html : this.note }, beforeEl);
        }
    });
});