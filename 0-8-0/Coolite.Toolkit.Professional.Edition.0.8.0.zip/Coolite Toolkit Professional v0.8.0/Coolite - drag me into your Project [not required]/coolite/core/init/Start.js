Ext.ns("Coolite", "Coolite.Ext", "Coolite.AjaxMethods", "Ext.ux", "Ext.ux.plugins", "Ext.ux.layout");

Coolite.Ext.Version = "0.8.0";