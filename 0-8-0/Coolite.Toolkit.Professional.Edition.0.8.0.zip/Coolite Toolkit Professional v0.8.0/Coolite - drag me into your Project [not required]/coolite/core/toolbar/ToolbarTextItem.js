
// @source core/toolbar/ToolbarTextItem.js

Ext.Toolbar.TextItem.override({
    setText : function (text) {
        this.el.innerHTML = text;
    },
    
    getText : function () {
        return this.el.innerHTML;
    }
});