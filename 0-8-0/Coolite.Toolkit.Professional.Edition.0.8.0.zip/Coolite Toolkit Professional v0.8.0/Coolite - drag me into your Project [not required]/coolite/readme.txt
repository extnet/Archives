http://code.google.com/p/js-builder/
http://extjs.com/learn/Tutorial:Building_Ext_From_Source#JS_Builder