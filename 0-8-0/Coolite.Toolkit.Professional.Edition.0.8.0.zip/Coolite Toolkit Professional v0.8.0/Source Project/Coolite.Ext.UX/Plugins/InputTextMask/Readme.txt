﻿ExtJs Forum post: http://extjs.com/forum/showthread.php?t=21040
Project on GoogleCode: http://code.google.com/p/cherryonext/