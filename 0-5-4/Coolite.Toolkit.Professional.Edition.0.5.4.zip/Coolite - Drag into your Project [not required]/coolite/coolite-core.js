Ext.FormViewport = Ext.extend(Ext.Container, {
    initComponent : function() {      
        Ext.FormViewport.superclass.initComponent.call(this);
        document.getElementsByTagName("html")[0].className += " x-viewport";
        this.el = Ext.get(document.forms[0]);
        this.el.setHeight = Ext.emptyFn;
        this.el.setWidth = Ext.emptyFn;
        this.el.setSize = Ext.emptyFn;
        this.el.dom.scroll = "no";
        this.allowDomMove = false;
        this.autoWidth = true;
        this.autoHeight = true;
        Ext.EventManager.onWindowResize(this.fireResize, this);
        this.renderTo = this.el;
        Ext.getBody().applyStyles({
            overflow: "hidden",
            margin: "0",
            padding: "0",
            border: "0px none",
            height: "100%"
        });
        document.getElementsByTagName("html")[0].style["height"] = "100%";
        document.forms[0].style["height"] = "100%";   
        document.forms[0].style["width"] = "100%";            
    },

    fireResize : function(w, h){
        this.fireEvent("resize", this, w, h, w, h);
    }
});
Ext.reg("FormViewport", Ext.FormViewport);


Ext.layout.FormAnchorLayout = Ext.extend(Ext.layout.AnchorLayout, {
    monitorResize:true,
    getAnchorViewSize : function(ct, target){
        return target.dom == document.forms[0] ?
                   target.getViewSize() : target.getStyleSize();
    }   
});

Ext.Container.LAYOUTS["formanchor"] = Ext.layout.FormAnchorLayout;

Ext.layout.FitLayout = Ext.extend(Ext.layout.ContainerLayout, {
    // private
    monitorResize:true,

    // private
    onLayout : function(ct, target){
        Ext.layout.FitLayout.superclass.onLayout.call(this, ct, target);
        if(!this.container.collapsed){
           if(target.dom == document.forms[0]){
                this.setItemSize(this.activeItem || ct.items.itemAt(0), Ext.getBody().getViewSize());
           }
           else{
              this.setItemSize(this.activeItem || ct.items.itemAt(0), target.getStyleSize());
           }             
        }
    },

    // private
    setItemSize : function(item, size){
        if(item && size.height > 0){ // display none?
            item.setSize(size);
        }
    }
});
Ext.Container.LAYOUTS['fit'] = Ext.layout.FitLayout;

if(typeof Sys!=="undefined"){Sys.Application.notifyScriptLoaded();}