﻿Project      : Ext.NET.Utilties
Version      : 2.5.0
Last Updated : 2014-10-20

--------------------------------------------------------------------------
DESCRIPTION
--------------------------------------------------------------------------

A .NET Utility Class Library for Ext.NET (http://ext.net/)

Install using NuGet (http://nuget.org/packages/Ext.NET.Utilities).

    Install-Package Ext.NET.Utilities


--------------------------------------------------------------------------
RELEASE HISTORY
--------------------------------------------------------------------------

2014-10-20

- Release v2.4.0
- Added DateTime string formatting support for patterns 'f', 'F', 'f' and 'G'


2013-12-17

- Release v2.4.0


2013-10-04

- Release v2.3.0


2013-04-16

- Release v2.2.1


2013-03-20

- Release v2.2.0


2012-11-19

- Release v2.1.0


2012-05-24

- Release v2.0.1


2012-03-05

- Release v2.0.0