﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.MessageBus_Basic.Controllers
{
    public class ComplexController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
