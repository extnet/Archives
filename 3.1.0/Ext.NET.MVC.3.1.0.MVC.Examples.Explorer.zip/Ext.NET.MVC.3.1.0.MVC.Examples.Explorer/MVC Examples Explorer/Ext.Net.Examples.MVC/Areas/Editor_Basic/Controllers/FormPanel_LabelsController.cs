﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Editor_Basic.Controllers
{
    public class FormPanel_LabelsController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
