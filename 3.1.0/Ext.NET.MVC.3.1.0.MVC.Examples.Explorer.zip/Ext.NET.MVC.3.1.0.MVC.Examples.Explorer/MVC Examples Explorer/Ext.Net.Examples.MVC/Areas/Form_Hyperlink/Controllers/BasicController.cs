﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Form_Hyperlink.Controllers
{
    public class BasicController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
