﻿Version: 0.3.1
Last Updated: 13-Feb-2008

----------------------------------------------------------
MANUAL TOOLBOX INSTALLATION INSTRUCTIONS
----------------------------------------------------------

The following steps are required to manually install the controls into your Visual Studio or Visual Web Developer Express Toolbox. 
		
	1. Open Visual Studio or Visual Web Developer

	2. Open an existing or create a new web Project.
	
	3. Open or create a new .aspx page.

	4. Open the ToolBox panel. Typically located on the left side in a fly-out panel (Ctrl + Alt + x).

	5. Create a new "Coolite" Tab, by...
		a. Right-Click in the ToolBox area.
		b. Select "Add Tab".
		c. Enter "Coolite".

	6. Inside the "Coolite" tab, Right-Click and select "Choose Items...".

	7. Under the ".NET Framework Components" Tab select the "Browse" button.

	8. Navigate to and select the Coolite.Web.UI.dll file, choose open.
			
			NOTE: If the automatic installer has been run previously, the Coolite.Web.UI.dll can typically be found in the following location:
            
            C:\Program Files\Coolite\Coolite.Web.UI - Version 0.3\

	9. The component items should now be added to the list and pre-checked. You can confirm by sorting the list by "Namespace" and scrolling to "Coolite.Web.UI"

	10. Click "OK". The icons should be added to your ToolBox. You should now be able to drag/drop a Coolite component onto your WebForm.
	
	11. Enjoy.
	
	
	
	
	
Copyright 2006-2008 Coolite Inc., All rights reserved.

Coolite Inc.
    208, 10113 104 Street
    Edmonton, Alberta, Canada    T5J1A1
    Phone:    +1(888)775-5888
    Website:  http://www.coolite.com/
    Support:  http://www.coolite.com/support/