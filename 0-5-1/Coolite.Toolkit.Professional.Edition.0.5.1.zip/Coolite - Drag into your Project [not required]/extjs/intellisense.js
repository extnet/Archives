﻿window.addEventListener = false;
if(typeof Sys!=="undefined"){Sys.Application.notifyScriptLoaded();}