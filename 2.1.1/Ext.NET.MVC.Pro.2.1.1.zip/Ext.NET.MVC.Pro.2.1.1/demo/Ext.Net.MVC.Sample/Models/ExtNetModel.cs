﻿namespace Ext.Net.MVC.Sample.Models
{
    public class ExtNetModel
    {
        public string WindowTitle { get; set; }
        public string TextAreaEmptyText { get; set; }
    }
}