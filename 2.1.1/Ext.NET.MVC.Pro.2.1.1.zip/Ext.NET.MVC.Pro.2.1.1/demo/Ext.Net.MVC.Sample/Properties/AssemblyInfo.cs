﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("2.1.1.*")]
[assembly: AssemblyFileVersion("2.1.1.*")]
[assembly: AssemblyTitle("Ext.Net.MVC.Sample")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ext.NET, Inc.")]
[assembly: AssemblyProduct("Ext.Net.MVC.Sample")]
[assembly: AssemblyCopyright("Copyright © 2007-2012 Ext.NET, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("ded4b9cb-ef22-4d44-a798-ea24530b41bd")]