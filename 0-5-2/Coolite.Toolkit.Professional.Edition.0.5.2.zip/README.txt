﻿Version: 0.5.2
Last Updated: 2008-06-19

--------------------------------------------------------------------------
             ADD TO VISUAL STUDIO TOOLBOX INSTRUCTIONS
--------------------------------------------------------------------------

The following steps are required to manually install the controls into 
your Visual Studio or Visual Web Developer Express Toolbox. 
		
	1.  Open Visual Studio or Visual Web Developer Express.

	2.  Open an existing web site or create a new web site project.
	
	3.  Open or create a new .aspx page.

	4.  Open the ToolBox panel, typically located on the left side in a 
	    fly-out panel (Ctrl + Alt + x).

	5.  Create a new "Coolite" Tab, by...
		  a. Right-Click in the ToolBox area.
		  b. Select "Add Tab".
		  c. Enter "Coolite".

	6.  Inside the "Coolite" tab, Right-Click and select 
	    "Choose Items...".

	7.  Under the ".NET Framework Components" Tab select the "Browse" 
	    button.

	8.  Navigate to and select the Coolite.Ext.Web.dll file, choose open.
			
          NOTE: If the automatic installer has been run previously, the 
                Coolite.Ext.Web.dll can typically be found in the 
                following location:

                C:\Program Files\Coolite\Coolite Toolkit - Version 0.5.2\

	9.  The component items should now be added to the list and 
	    pre-checked. You can confirm by sorting the list by "Namespace" 
	    and scrolling to "Coolite.Ext.Web"

	10. Click "OK". The icons should be added to your ToolBox. You should 
	    now be able to drag/drop a Coolite component onto your WebForm.
	
	11. Enjoy.

--------------------------------------------------------------------------
                   Version 0.5.2 BREAKING CHANGES
--------------------------------------------------------------------------

1.  Renamed the "HorizontalAnchor" and "VerticalAnchor" properties of
    AnchorLayout to just "Horizontal" and "Vertical".
    
    Example (Old)
    
    <ext:Anchor HorizontalAnchor="100%" VerticalAnchor="100%">
    
    Example (New)
    
    <ext:Anchor Horizontal="100%" Vertical="100%">

--------------------------------------------------------------------------
                   Version 0.5.0 BREAKING CHANGES
--------------------------------------------------------------------------

1.  Renamed Assembly from Coolite.Web.UI to Coolite.Ext.Web. 
    The new main dll is now Coolite.Ext.Web.dll.

	@Register statement must be updated.
	
	Example (Old)
	
	<%@ Register Assembly="Coolite.Web.UI" 
	        Namespace="Coolite.Web.UI" TagPrefix="cool" %>
	
	Example (New)
	
	<%@ Register Assembly="Coolite.Ext.Web" 
	        Namespace="Coolite.Ext.Web" TagPrefix="ext" %>
    
    
    Example (Old)
    
	<pages>
		<controls>
			<add tagPrefix="cool" namespace="Coolite.Web.UI" 
			        assembly="Coolite.Web.UI"/>
		</controls>
	</pages>
	
	Example (New)
	
	<pages>
		<controls>
			<add tagPrefix="ext" namespace="Coolite.Ext.Web" 
			        assembly="Coolite.Ext.Web"/>
		</controls>
	</pages>

2.  Rename Toolbox extension from <cool: to <ext:

	Example (Old)
	
	<cool:Window runat="server" id="Window1" />
	
	Example (New)
	
	<ext:Window runat="server" id="Window1" />
		
3.  Renamed all "ClientEvents" properties to "Listeners". 

    Example (Old)
    
	<cool:Window ID="Window1" runat="server">
		<ClientEvents>
			<Show Handler="Ext.emptyFn" />
		</ClientEvents>
	</ext:Window>
    
    
    Example (New)
    
	<ext:Window ID="Window1" runat="server">
		<Listeners>
			<Show Handler="Ext.emptyFn" />
		</Listeners>
	</ext:Window>

4.	Added convenience functionality to Listener "Hander" property so 
    wrapping custom event handler logic with JavaScript 'function' is no 
    longer required.

	Example (Old)

	<Resize Handler="function(el){console.log(el.getSize());}" />

	Example (New)
	
	<Resize Handler="console.log(el.getSize());" />

	By default, the .Handler property will wrap it's value with the proper 
	'function' syntax and pass the correct arguments for each event. Each 
	argument is listed in the ExtJS documentation (Resize Sample) and will 
	be available from Intellisense.	

5.  Changed Window "AutoShow" property to "ShowOnLoad". The ShowOnLoad 
    property is 'true' by default. To not show the Window automatically on 
    Page load, please set the ShowOnLoad property to 'false'
	
	Example (Old)
	
	<cool:Window runat="server" id="Window1" AutoShow="true" />
	
	Example (New)
	
	// Show Window on Page load
	<ext:Window runat="server" id="Window1" />
	
	// Do not show Window on Page load
	<ext:Window runat="server" id="Window1" ShowOnLoad="False" /> 

6.  Changed Window "Center" property to "CenterOnLoad". The CenterOnLoad 
    property is 'true' by default and will center the Window in the 
    viewport on initial Page load.
	
	Example (Old)
	
	<cool:Window runat="server" id="Window1" Center="true" />
	
	Example (New)
	
	// Center Window on Page load
	<ext:Window runat="server" id="Window1" /> 
	
	// Do not center Window on Page load
	<ext:Window runat="server" id="Window1" CenterOnLoad="False" /> 
	
7.  Renamed TextBox control to TextField.

	Example (Old)
	
	<cool:TextBox runat="server" id="TextBox1" />
	
	Example (New)
	
	<ext:TextField runat="server" id="TextField1" />
	
8.  Renamed DatePicker control to DateField.

	Example (Old)
	
	<cool:DatePicker runat="server" id="DatePicker1" />
	
	Example (New)
	
	<ext:DateField runat="server" id="DateField1" />
	
9.  Renamed Calendar control to DatePicker.

	Example (Old)
	
	<cool:Calendar runat="server" id="Calendar1" />
	
	Example (New)
	
	<ext:DatePicker runat="server" id="DatePicker1" />	

10. Renamed CheckBox control to Checkbox (<-- notice lowercase 'b').
	
	Example (Old)
	
	<cool:CheckBox runat="server" id="CheckBox1" />
	
	Example (New)
	
	<ext:Checkbox runat="server" id="Checkbox1" />
	
11. Renamed HiddenField control to Hidden.
	
	Example (Old)
	
	<cool:HiddenField runat="server" id="HiddenField1" />
	
	Example (New)
	
	<ext:Hidden runat="server" id="Hidden1" />	

12. Renamed NumberTextBox control to NumberField.
	
	Example (Old)
	
	<cool:NumberTextBox runat="server" id="NumberTextBox1" />
	
	Example (New)
	
	<ext:NumberField runat="server" id="NumberField1" />		
	
13. Renamed RadioButton control to Radio.
	
	Example (Old)
	
	<cool:RadioButton runat="server" id="RadioButton1" />
	
	Example (New)
	
	<ext:Radio runat="server" id="Radio1" />	
    
--------------------------------------------------------------------------

--------------------------------------------------------------------------
	
        Copyright 2006-2008 Coolite Inc., All rights reserved.
                  
                             Coolite Inc.
                        208, 10113 104 Street
                   Edmonton, Alberta, Canada T5J 1A1
                           +1(888)775-5888
                           +1(780)757-2694
                           www.coolite.com
                           info@coolite.com