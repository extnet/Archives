﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.GridPanel_Data_with_Details.Binding.Controllers
{
    public class BindingController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
