﻿function fullNameBuilder (value, record) {
    return record.data.LastName + ', ' + record.data.FirstName;
}