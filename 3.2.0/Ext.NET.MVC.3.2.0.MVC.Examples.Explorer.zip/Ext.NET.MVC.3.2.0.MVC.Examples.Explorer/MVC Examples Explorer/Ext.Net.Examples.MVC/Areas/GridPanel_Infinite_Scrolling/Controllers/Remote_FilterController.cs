﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.GridPanel_Infinite_Scrolling.Controllers
{
    public class Remote_FilterController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
