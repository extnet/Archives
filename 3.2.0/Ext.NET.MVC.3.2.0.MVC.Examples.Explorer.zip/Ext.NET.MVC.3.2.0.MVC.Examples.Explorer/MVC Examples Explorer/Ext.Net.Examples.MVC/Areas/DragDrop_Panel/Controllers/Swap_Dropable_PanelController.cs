﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.DragDrop_Panel.Controllers
{
    public class Swap_Dropable_PanelController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
