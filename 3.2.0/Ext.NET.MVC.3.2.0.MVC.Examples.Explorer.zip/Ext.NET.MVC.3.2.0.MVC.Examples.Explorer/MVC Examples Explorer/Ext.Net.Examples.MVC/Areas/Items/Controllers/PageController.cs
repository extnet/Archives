﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Items.Controllers
{
    public class PageController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
