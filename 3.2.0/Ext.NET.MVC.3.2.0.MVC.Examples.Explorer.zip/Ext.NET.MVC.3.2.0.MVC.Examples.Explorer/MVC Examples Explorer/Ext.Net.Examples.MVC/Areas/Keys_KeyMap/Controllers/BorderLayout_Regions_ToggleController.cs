﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Keys_KeyMap.Controllers
{
    public class BorderLayout_Regions_ToggleController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
