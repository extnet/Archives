﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.DragDrop_Basic.Controllers
{
    public class Example1Controller : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
