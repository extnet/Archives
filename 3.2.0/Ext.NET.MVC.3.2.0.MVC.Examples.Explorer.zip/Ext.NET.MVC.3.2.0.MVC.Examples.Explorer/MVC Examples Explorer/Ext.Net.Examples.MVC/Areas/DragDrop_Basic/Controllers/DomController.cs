﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.DragDrop_Basic.Controllers
{
    public class DomController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
