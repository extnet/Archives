﻿using System;
using System.Collections;

namespace Ext.Net.MVC.Examples.Areas.GridPanel_Miscellaneous.Models
{
    public class Marking_RecordsModel
    {      
        public IEnumerable TestData
        {
            get
            {
                return new object[]
                {
                    new object[] { "Sample 1" },
                    new object[] { "Sample 2" },
                    new object[] { "Sample 3" },
                    new object[] { "Sample 4" },
                    new object[] { "Sample 5" },
                    new object[] { "Sample 6" },
                    new object[] { "Sample 7" },
                    new object[] { "Sample 8" },
                    new object[] { "Sample 9" },
                    new object[] { "Sample 10" },
                    new object[] { "Sample 11" },
                    new object[] { "Sample 12" },
                    new object[] { "Sample 13" },
                    new object[] { "Sample 14" },
                    new object[] { "Sample 15" }
                };
            }
        }

    }
}
