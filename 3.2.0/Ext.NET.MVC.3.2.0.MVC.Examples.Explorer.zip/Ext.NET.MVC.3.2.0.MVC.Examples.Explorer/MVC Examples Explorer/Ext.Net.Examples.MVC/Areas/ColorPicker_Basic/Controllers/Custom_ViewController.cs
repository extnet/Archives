﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.ColorPicker_Basic.Controllers
{
    public class Custom_ViewController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
