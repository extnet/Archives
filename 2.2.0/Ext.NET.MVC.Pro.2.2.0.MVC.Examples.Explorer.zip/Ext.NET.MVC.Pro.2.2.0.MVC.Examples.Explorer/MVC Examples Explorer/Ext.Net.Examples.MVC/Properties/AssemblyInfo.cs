﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ext.Net.MVC.Examples")]
[assembly: AssemblyDescription("Ext.Net.MVC.Examples")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ext.NET, Inc.")]
[assembly: AssemblyProduct("Ext.Net.MVC.Examples")]
[assembly: AssemblyCopyright("Copyright © 2007-2013 Ext.NET, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("0ad1c222-13cb-4c0b-bb33-2ca35f5bbce7")]
[assembly: AssemblyVersion("2.2.0.*")]
