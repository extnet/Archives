﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Miscellaneous_History.Controllers
{
    public class BasicController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
