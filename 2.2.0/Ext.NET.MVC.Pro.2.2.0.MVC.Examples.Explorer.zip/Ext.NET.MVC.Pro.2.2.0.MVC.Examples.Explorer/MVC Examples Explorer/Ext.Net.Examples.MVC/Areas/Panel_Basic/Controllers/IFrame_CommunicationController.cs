﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Panel_Basic.Controllers
{
	public class IFrame_CommunicationController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		public ActionResult A()
		{
			return View();
		}

		public ActionResult B()
		{
			return View();
		}
	}
}
