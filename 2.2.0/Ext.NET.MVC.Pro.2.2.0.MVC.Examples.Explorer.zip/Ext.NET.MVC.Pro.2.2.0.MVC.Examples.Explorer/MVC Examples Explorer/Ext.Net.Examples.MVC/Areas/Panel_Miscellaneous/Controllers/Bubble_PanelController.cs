﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Panel_Miscellaneous.Controllers
{
    public class Bubble_PanelController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
