﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.TabPanel_Basic.Controllers
{
    public class Advanced_TabController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
