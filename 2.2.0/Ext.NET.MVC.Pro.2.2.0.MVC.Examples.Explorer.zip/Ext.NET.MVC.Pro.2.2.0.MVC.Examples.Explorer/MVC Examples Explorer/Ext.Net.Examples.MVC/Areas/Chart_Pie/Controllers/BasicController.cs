﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Chart_Pie.Controllers
{
    public class BasicController : Controller
    {
        public ActionResult Index()
        {
            return View(ChartModel.GenerateData(6));
        }

		public ActionResult GetData()
        {
            return this.Direct(ChartModel.GenerateData(6));
        }
    }
}
