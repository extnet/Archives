/********
* @version: 0.6.0 - Professional Edition (Coolite Commercial License)
* @author: Coolite Inc. http://www.coolite.com/
* @date: 2008-08-05
* @copyright: Copyright (c) 2006-2008, Coolite Inc. (http://www.coolite.com/). All rights reserved.
* @license: See license.txt and http://www.coolite.com/license/. 
* @website: http://www.coolite.com/
********/

Ext.namespace('Coolite.Ext');

Coolite.Ext.Version = "0.6.0";

Coolite.Ext.FormViewport = Ext.extend(Ext.Container, {
    initComponent : function () {
        Coolite.Ext.FormViewport.superclass.initComponent.call(this);
        document.getElementsByTagName("html")[0].className += " x-viewport";
        this.el = Ext.get(document.forms[0]);
        this.el.setHeight = Ext.emptyFn;
        this.el.setWidth = Ext.emptyFn;
        this.el.setSize = Ext.emptyFn;
        this.el.dom.scroll = "no";
        this.allowDomMove = false;
        this.autoWidth = true;
        this.autoHeight = true;
        Ext.EventManager.onWindowResize(this.fireResize, this);
        this.renderTo = this.el;
        Ext.getBody().applyStyles({
            overflow: "hidden",
            margin: "0",
            padding: "0",
            border: "0px none",
            height: "100%"
        });
        document.getElementsByTagName("html")[0].style.height = "100%";
        document.forms[0].style.height = "100%";   
        document.forms[0].style.width = "100%";            
    },

    fireResize : function (w, h) {
        this.fireEvent("resize", this, w, h, w, h);
    }
});
Ext.reg("FormViewport", Coolite.Ext.FormViewport);


Ext.layout.FormAnchorLayout = Ext.extend(Ext.layout.AnchorLayout, {
    monitorResize: true,
    getAnchorViewSize : function (ct, target) {
        return target.dom == document.forms[0] ?
                   target.getViewSize() : target.getStyleSize();
    }   
});

Ext.Container.LAYOUTS.formanchor = Ext.layout.FormAnchorLayout;

Ext.layout.FitLayout = Ext.extend(Ext.layout.ContainerLayout, {
    // private
    monitorResize: true,

    // private
    onLayout : function (ct, target) {
        Ext.layout.FitLayout.superclass.onLayout.call(this, ct, target);
        if (!this.container.collapsed) {
            if (target.dom == document.forms[0]) {
                this.setItemSize(this.activeItem || ct.items.itemAt(0), Ext.getBody().getViewSize());
            } else {
                this.setItemSize(this.activeItem || ct.items.itemAt(0), target.getStyleSize());
            }             
        }
    },

    // private
    setItemSize : function (item, size) {
        if (item && size.height > 0) { // display none?
            item.setSize(size);
        }
    }
});

Ext.Container.LAYOUTS.fit = Ext.layout.FitLayout;

Ext.apply(Ext.lib.Ajax, {
    serializeForm: function(form) {
        if (typeof form == 'string') {
            form = (document.getElementById(form) || document.forms[form]);
        }

        var el, name, val, disabled, data = '', hasSubmit = false;
        hasSubmit = form.ignoreAllSubmitFields || false;
        for (var i = 0; i < form.elements.length; i++) {
            el = form.elements[i];
            disabled = form.elements[i].disabled;
            name = form.elements[i].name;
            val = form.elements[i].value;

            if (!disabled && name) {
                switch (el.type) {
                    case 'select-one':
                    case 'select-multiple':
                        for (var j = 0; j < el.options.length; j++) {
                            if (el.options[j].selected) {
                                if (Ext.isIE) {
                                    data += encodeURIComponent(name) + '=' + encodeURIComponent(el.options[j].attributes.value.specified ? el.options[j].value : el.options[j].text) + '&';
                                } else {
                                    data += encodeURIComponent(name) + '=' + encodeURIComponent(el.options[j].hasAttribute('value') ? el.options[j].value : el.options[j].text) + '&';
                                }
                            }
                        }
                        break;
                    case 'radio':
                    case 'checkbox':
                        if (el.checked) {
                            data += encodeURIComponent(name) + '=' + encodeURIComponent(val) + '&';
                        }
                        break;
                    case 'file':
                    case undefined:
                    case 'reset':
                    case 'button':
                        break;
                    case 'submit':
                        if (hasSubmit === false) {
                            data += encodeURIComponent(name) + '=' + encodeURIComponent(val) + '&';
                            hasSubmit = true;
                        }
                        break;
                    default:
                        data += encodeURIComponent(name) + '=' + encodeURIComponent(val) + '&';
                        break;
                }
            }
        }
        data = data.substr(0, data.length - 1);
        return data;
    }
});


Coolite.Ext.on = function(target, eventName, handler, scope, mode, cfg) {
    var el = target;
    if (typeof target == "string") {
        el = Ext.get(target);
    }

    if (!Ext.isEmpty(el)) {
        if (mode && mode == 'client') {
            el.on(eventName, handler.fn, scope, handler);
        } else {
            el.on(eventName, handler, scope, cfg);
        }
    }
};

Coolite.Ext.AjaxRequestType = {};
Coolite.Ext.AjaxRequestType.Event = 'Event';
Coolite.Ext.AjaxRequestType.CustomEvent = 'CustomEvent';
Coolite.Ext.AjaxRequestType.PostBack = 'PostBack';

Coolite.Ext.Callback = function() { };
Coolite.Ext.Callback.prototype = {
    setHiddenInputValue: function(form, name, value) {
        var input = null;
        if (form[name]) {
            input = form[name];
        } else {
            input = document.createElement("input");
            input.setAttribute("name", name);
            input.setAttribute("type", "hidden");
        }
        input.setAttribute("value", value);
        var parentElement = input.parentElement ? input.parentElement : input.parentNode;
        if (parentElement === null) {
            form.appendChild(input);
            form[name] = input;
        }
    },

    delayedF: function(el, remove) {
        if (!Ext.isEmpty(el)) {
            el.unmask();
            if (remove === true) {
                el.remove();
            }
        }
    },

    showFailure: function(response) {
        new Ext.Window({ modal: true, width: 500, height: 300, title: 'Request Failure', layout: 'fit', maximizable: true,
            listeners: {
                'maximize': {
                    fn: function(el) {
                        var v = Ext.getBody().getViewSize();
                        el.setSize(v.width, v.height);
                    },
                    scope: this
                }
            },

            items: new Ext.form.FormPanel({
                baseCls: 'x-plain',
                layout: 'absolute',
                defaultType: 'textfield',

                items: [
                                {
                                    x: 5,
                                    y: 5,
                                    xtype: 'label',
                                    html: '<div class="x-window-dlg"><div class="ext-mb-error" style="width:32;height:32"></div></div>'
                                }, {
                                    x: 42,
                                    y: 6,
                                    xtype: 'label',
                                    html: '<b>Status code: </b>'
                                }, {
                                    x: 115,
                                    y: 6,
                                    xtype: 'label',
                                    text: response.status
                                }, {
                                    x: 42,
                                    y: 25,
                                    xtype: 'label',
                                    html: '<b>Status text: </b>'
                                }, {
                                    x: 115,
                                    y: 25,
                                    xtype: 'label',
                                    text: response.statusText
                                }, {
                                    x: 0,
                                    y: 42,
                                    xtype: 'htmleditor',
                                    anchor: '100% 100%',
                                    enableAlignments: false,
                                    enableAlignments: false,
                                    enableColors: false,
                                    enableFont: false,
                                    enableFontSize: false,
                                    enableFormat: false,
                                    enableLinks: false,
                                    enableLists: false,
                                    enableSourceEdit: false,
                                    value: response.responseText
}]
            })

        }).show(null);
    },

    makeCallback: function(requestCfg, extraParams, control, type, action, serviceParams) {

        var requestConfig = requestCfg || {};
        var formId = requestConfig.formProxyArg;
        var url = requestConfig.url || Coolite.Ext.ThisUrl;

        var form = null;

        if (requestCfg.type !== 'load') {
            if (!Ext.isEmpty(formId)) {
                form = Ext.get(formId);
            } else {
                if (control.el && control.el !== null && (Ext.isEmpty(control.isComposite) || control.isComposite === false)) {
                    form = control.el.up('form');
                }
            }
        }

        var submitConfig = {};
        var argument = String.format('{0}|{1}|{2}', control.proxyId || control.id || '-', type, action);
        if (form !== null) {
            this.setHiddenInputValue(form.dom, "__EVENTTARGET", Coolite.Ext.ScriptManagerUniqueID);
            this.setHiddenInputValue(form.dom, "__EVENTARGUMENT", argument);
        } else {
            Ext.apply(submitConfig, { __EVENTTARGET: Coolite.Ext.ScriptManagerUniqueID, __EVENTARGUMENT: argument });
        }

        Ext.apply(submitConfig, { enableViewState: requestConfig.enableViewState || false });


        var userParams = requestConfig.userParams || {};

        if (form !== null) {
            Ext.apply(userParams, { form: form.id });
        } else {
            Ext.apply(userParams, { url: url });
        }

        if (!Ext.isEmpty(extraParams)) {
            Ext.apply(userParams, extraParams);
        }

        if (requestConfig.before) {
            if (requestConfig.before(control, type, action, userParams) === false) {
                return;
            }
        }

        Ext.apply(submitConfig, { userParams: userParams || {} });

        if (!Ext.isEmpty(serviceParams)) {
            Ext.apply(submitConfig, { serviceParams: serviceParams });
        }

        var el, remove = false, em = requestConfig.eventMask || {};

        if ((em.showMask || false)) {
            switch (em.target || "page") {
                case "this":
                    if (control.getEl) {
                        el = control.getEl();
                    } else if (control.dom) {
                        el = control;
                    }
                    break;
                case "parent":
                    if (control.getEl) {
                        el = control.getEl().parent();
                    } else if (control.parent) {
                        el = control.parent();
                    }
                    break;
                case "page":
                    el = Ext.getBody().createChild({ style: "position:absolute;left:0;top:0;width:100%;height:100%;z-index:20000;background-color:Transparent;" });
                    var scroll = Ext.getBody().getScroll();
                    el.setLeftTop(scroll.left, scroll.top);
                    remove = true;
                    break;
                case "customtarget":
                    var trg = em.customTarget || '';
                    el = Ext.get(trg);
                    if (el == null) {
                        el = trg.getEl ? trg.getEl() : null;
                    }
                    break;
            }

            if (el !== undefined && el !== null) {
                el.mask(em.msg || 'Working...', em.msgCls || 'x-mask-loading');
            }
        }

        var removeMask = function(scope) {
            if (el !== undefined && el !== null) {
                var delay = 0;
                if (em && em.minDelay) {
                    delay = em.minDelay;
                }

                setTimeout(function() {
                    scope.delayedF(el, remove);
                }, delay);
            }
        };

        var executeScript = function(result, response) {
            var delay = 0;

            if (em && em.minDelay) {
                delay = em.minDelay;
            }

            setTimeout(function() {
                if (result.script && result.script.length > 0) {
                    eval(result.script);
                }

                if (requestConfig.success) {
                    requestConfig.success(response, result, control, type, action, userParams);
                }
            }, delay);
        };

        var options = {
            headers: {
                "X-Coolite": "delta=true"
            },
            scope: this,
            params: { submitEventCallbackConfig: Ext.encode({ config: submitConfig }) },
            failure: function(response, options) {

                removeMask(options.scope);
                if (requestConfig.failure) {
                    requestConfig.failure(response, { "error": response.statusText }, control, type, action, userParams);
                } else {
                    if (requestConfig.showWarningOnFailure !== false) {
                        this.showFailure(response);
                    }
                }
            },
            success: function(response, options) {
                removeMask(options.scope);
                var result = {};
                var exception = false;

                try {
                    result = eval("(" + response.responseText + ")");
                } catch (e) {
                    result.success = false;
                    exception = true;
                    if (response.responseText.length === 0) {
                        result.errorMessage = "NORESPONSE";
                    } else {
                        result.errorMessage = "BADRESPONSE: " + e.message;
                        result.responseText = response.responseText;
                    }

                    response.statusText = result.errorMessage;
                }

                if (result.success === false) {

                    if (requestConfig.failure) {
                        requestConfig.failure(response, result, control, type, action, userParams);
                    } else {
                        if (requestConfig.showWarningOnFailure !== false) {
                            if (!exception) {
                                response.responseText = result.errorMessage;
                            }
                            this.showFailure(response);
                        }
                    }
                    return;
                }

                if (result.viewState && result.viewState.length > 0 && form !== null) {
                    options.scope.setHiddenInputValue(form.dom, "__VIEWSTATE", result.viewState);
                }
                if (result.viewStateEncrypted && result.viewStateEncrypted.length > 0 && form !== null) {
                    options.scope.setHiddenInputValue(form.dom, "__VIEWSTATEENCRYPTED", result.viewStateEncrypted);
                }
                if (result.eventValidation && result.eventValidation.length > 0 && form !== null) {
                    options.scope.setHiddenInputValue(form.dom, "__EVENTVALIDATION", result.eventValidation);
                }

                executeScript(result, response);
            }
        };

        if (form !== null) {
            Ext.apply(options, { form: form });
            Ext.getDom(form).ignoreAllSubmitFields = true;
        } else {
            Ext.apply(options, { url: url });
        }

        Ext.Ajax.request(options);
    }
};

    Ext.form.Hidden.override({
        setValue: function(v) {
            this.value = v;
            var temp = this.el.dom.value;
            if (this.rendered) {
                this.el.dom.value = (v === null || v === undefined ? '' : v);
                this.validate();
            }
            if (this.el.dom.value != temp) {
                this.fireEvent('change');
            }
        }
    });

    Ext.form.Label.override({
        onRender: function(ct, position) {
            if (!this.el) {
                this.el = document.createElement((this.forId) ? 'label' : 'span');
                this.el.id = this.getId();
                this.el.innerHTML = this.text ? Ext.util.Format.htmlEncode(this.text) : (this.html || '');
                if (this.forId) {
                    this.el.setAttribute('htmlFor', this.forId);
                }
            }
            Ext.form.Label.superclass.onRender.call(this, ct, position);
        } 
    });


    Ext.Panel.override({
        setAutoScroll: function() {
            if (this.rendered && this.autoScroll) {
                var el = this.body || this.el;
                if (el) {
                    el.setOverflow('auto');
                    // Following line required to fix autoScroll
                    el.dom.style.position = 'relative';
                }
            }
        }
    });

    Ext.ns('Ext.ux.layout');

    Ext.ux.layout.CenterLayout = Ext.extend(Ext.layout.FitLayout, {
        // private
        setItemSize: function(item, size) {
            this.container.addClass('ux-layout-center');
            item.addClass('ux-layout-center-item');
            if (item && size.height > 0) {
                if (item.width) {
                    size.width = item.width;
                }
                item.setSize(size);
            }
        }
    });
    Ext.Container.LAYOUTS['ux.center'] = Ext.ux.layout.CenterLayout;

    Ext.ux.layout.RowLayout = Ext.extend(Ext.layout.ContainerLayout, {
        // private
        monitorResize: true,

        // private
        isValidParent: function(c, target) {
            return c.getEl().dom.parentNode == this.innerCt.dom;
        },

        // private
        onLayout: function(ct, target) {
            var rs = ct.items.items, len = rs.length, r, i;

            if (!this.innerCt) {
                target.addClass('ux-row-layout-ct');
                this.innerCt = target.createChild({ cls: 'x-row-inner' });
            }
            this.renderAll(ct, this.innerCt);

            var size = target.getViewSize();

            if (size.width < 1 && size.height < 1) { // display none?
                return;
            }

            var h = size.height - target.getPadding('tb'),
            ph = h;

            this.innerCt.setSize({ height: h });

            // some rows can be percentages while others are fixed
            // so we need to make 2 passes

            for (i = 0; i < len; i++) {
                r = rs[i];
                if (!r.rowHeight) {
                    ph -= (r.getSize().height + r.getEl().getMargins('tb'));
                }
            }

            ph = ph < 0 ? 0 : ph;

            for (i = 0; i < len; i++) {
                r = rs[i];
                if (r.rowHeight) {
                    r.setSize({ height: Math.floor(r.rowHeight * ph) - r.getEl().getMargins('tb') });
                }
            }
        }

        /**
        * @property activeItem
        * @hide
        */
    });
    Ext.Container.LAYOUTS['ux.row'] = Ext.ux.layout.RowLayout;
        
 if(typeof Sys!=="undefined"){Sys.Application.notifyScriptLoaded();}