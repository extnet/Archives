﻿Version: 0.6.0
Last Updated: 2008-10-02

--------------------------------------------------------------------------
                  ENABLE AJAXEVENTS IN WEB.CONFIG
--------------------------------------------------------------------------

The release of Version 0.6.0 has introduced a new feature called 
"AjaxEvents". The AjaxEvents enable an Ajax postback to be attached to 
any event.

The AjaxEvents perform a full PostBack, but do this threw the use of Ajax.
The Page will go threw it's entire page life-cycle as a classic postback, 
although will only return JavaScript in the response. The JavaScript is 
then executed on the client on successful round trip. 

No HTML is returned from the AjaxEvent. Currently, a new control can not
be created during an AjaxEvent. All controls that require updating on the 
client must be available in the Page .Controls Collection before the 
AjaxEvent executes. 

To enable the AjaxEvents functionality you must add the following 
"AjaxRequestModule" node to your projects Web.config file.

Example

<system.web>
	<httpModules>
		<add name="AjaxRequestModule" 
			type="Coolite.Ext.Web.AjaxRequestModule, Coolite.Ext.Web" />
	</httpModules>
</system.web>

Once the "AjaxRequestModule" has been added to the web.config, you can 
trigger an AjaxEvent by adding to the <AjaxEvents> property of each 
Coolite Toolkit control.

The following demonstrates setting the <Click> AjaxEvent on an 
<{0}:Button> and then calling .Show() on an <{0}:Window> control. 

Example

<script runat="server">
    protected void Button1_Click(object sender, AjaxEventArgs e)
    {
        this.Window1.Show();
    }
</script>

<{0}:Button ID="Button1" runat="server" Text="Show Window">
    <AjaxEvents>
        <Click OnEvent="Button1_Click" />
    </AjaxEvents>
</{0}:Button>

	
--------------------------------------------------------------------------
             ADD TO VISUAL STUDIO TOOLBOX INSTRUCTIONS
--------------------------------------------------------------------------

The following steps are required to manually install the controls into 
your Visual Studio or Visual Web Developer Express Toolbox. 
		
	1.  Open Visual Studio or Visual Web Developer Express.

	2.  Open an existing web site or create a new web site project.
	
	3.  Open or create a new .aspx page.

	4.  Open the ToolBox panel, typically located on the left side in a 
	    fly-out panel (Ctrl + Alt + x).

	5.  Create a new "Coolite Toolkit" Tab, by...
		  a. Right-Click in the ToolBox area.
		  b. Select "Add Tab".
		  c. Enter "Coolite".

	6.  Inside the "Coolite Toolkit" tab, Right-Click and select 
	    "Choose Items...".

	7.  Under the ".NET Framework Components" Tab select the "Browse" 
	    button.

	8.  Navigate to and select the Coolite.Ext.Web.dll file, choose open.
			
          NOTE: If the automatic installer has been run previously, the 
                Coolite.Ext.Web.dll can typically be found in the 
                following location:

                C:\Program Files\Coolite\Coolite Toolkit - Version 0.6.0\

	9.  The component items should now be added to the list and 
	    pre-checked. You can confirm by sorting the list by "Namespace" 
	    and scrolling to "Coolite.Ext.Web"

	10. Click "OK". The icons should be added to your ToolBox. You should 
	    now be able to drag/drop a Coolite component onto your WebForm.
	
	11. Enjoy.

--------------------------------------------------------------------------
                   Version 0.6.0 BREAKING CHANGES
--------------------------------------------------------------------------

1.  The Enum type of Window.TriggerEvent property has changed from 
	TriggerEvent to HtmlEvent. 
	
	Example (Old)
	
	Window1.TriggerEvent = TrigerEvent.Click;
	
	Example (New)
	
	Window1.TriggerEvent = HtmlEvent.Click;
	
	The markup syntax has not changed. 
	
	Example
	
	<{0}:Window runat="server" TriggerEvent="Click" />
	
	Several new html events added including:
	
	i.   Abort
	ii.  Submit
	iii. Unload
	
2.  The default value for the Window.CloseAction property has changed from
	CloseAction.Close to CloseAction.Hide. Now by default Windows will not
	be destroyed when closed. 
	
	In general, developers should not have to change their existing 
	project source code. If the property is explicityly being set to 
	CloseAction.Hide, then that property can be removed, but is optional.
	
3.  The TokenID format has changed from "{ControlID}" to "#{ControlID}". 
	
	Example (Old)
	
	<Listeners>
		<Click Handler="{Panel1}.expand();" />
	</Listeners>

	Example (New)
	
	<Listeners>
		<Click Handler="#{Panel1}.expand();" />
	</Listeners>
	
	The TokenID will be parsed and replaced with the .ClientID of the 
	control it references. All Coolite Toolkit controls are instantiated 
	client-side using their .ClientID. The .ClientID may be different than 
	the controls .ID property if the control is rendered within an 
	INamingContainer control such as a MasterPage.
	
4.  The <{0}:Hidden> and <{0}:ScriptManager> "Hide" property have been 
	renamed to "HideInDesign". The "HideInDesign" property will hide the 
	control when Visual Studio is in Design-Mode. The property has no
	affect on any runtime rendering of the control.
	
	The "Hide" was renamed to avoid confusion with the "Hidden" property 
	and the .Hide() Method, both of which "hide" the control when rendered
	in the browser. 
	
	If the control is "hidden" at runtime, it's still available in the DOM 
	just as through it was not hidden. Any JavaScript run against a hidden 
	control will continue to work as expected and no JavaScript error will 
	be thrown. The control is still there... it's just "hidden", kind of 
	like "The Invisble Man", see
	http://en.wikipedia.org/wiki/The_Invisible_Man
	
5.  The .ActiveTab property has changed.

	In previous versions the .ActiveTab property was an 'int' type, but 
	has now been changed to a type of 'Tab'. 

	The following sample demonstrates how to set the ActiveTabIndex in
	markup.

	Example (old)

	<{0}:TabPanel 
		ID="TabPanel1" 
		runat="server" 
		ActiveTab="1" 
		Title="Title">
		
	Example (new)

	<{0}:TabPanel 
		ID="TabPanel1" 
		runat="server" 
		ActiveTabIndex="1" 
		Title="Title">		

	The new .ActiveTabIndex property has been added to replace the 
	previous .ActiveTab functionality. 

	The .ActiveTab property is now used in code-behind to programatically 
	get/set an instance of the active tab.
	
6.	The <{0}:Window> .TriggerElement property has been removed. 
	
	Please "show" the Window by using a Listener or AjaxEvent on the 
	launching element/control.
	
	Example (Listener)
	
	<{0}:Button ID="Button1" runat="server" Text="Show Window">
		<Listeners>
			<Click Handler="Window1.show()" />
		</Listeners>
	</{0}:Button>
	
	Example (AjaxEvent)
	
	<script runat="server">
		protected void Button_Click(object sender, AjaxEventArgs e)
		{
			this.Window1.Show();
		}
	</script>
	
	<{0}:Button ID="Button1" runat="server" Text="Show Window">
		<AjaxEvents>
			<Click OnEvent="Button1_Click" />
		</AjaxEvents>
	</{0}:Button>
	
7.	The <{0}:Window> .TriggerEvent property has been removed. 
	
	See above #6. Now any Listener or AjaxEvent from any element/component
	can "trigger" an event to fire.

8.	The default value of the <{0}:Button> .AutoPostBack property has been 
	changed from "true" to "false".
	
	In Visual Studio DesignMode, double clicking on the <{0}:Button> will 
	automatically wire up the "OnClick" event handler, but as with other 
	postback enabled controls, such as <asp:TextBox>, the developer will 
	now have to explicitly set the .AutoPostBack property to "true".
	
	Please see the following forum post for more information, see
	http://coolite.com/forums/FindPost2044.aspx
	
--------------------------------------------------------------------------
                               CREDITS
--------------------------------------------------------------------------
	
1.  FamFamFam Icons provided by Mark James 
	http://www.famfamfam.com/lab/icons/silk/
	
	See \Build\Resources\Coolite\icons\readme.txt for more information.

--------------------------------------------------------------------------
                               
--------------------------------------------------------------------------
	
        Copyright 2006-2008 Coolite Inc., All rights reserved.
                  
                             Coolite Inc.
                        208, 10113 104 Street
                   Edmonton, Alberta, Canada T5J 1A1
                           +1(888)775-5888
                           www.coolite.com
                           info@coolite.com