﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Layout_Accordion.Controllers
{
    public class Basic_In_MarkupController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
