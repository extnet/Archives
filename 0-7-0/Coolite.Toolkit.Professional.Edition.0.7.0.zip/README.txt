﻿Version: 0.7.0
Last Updated: 2008-12-22
	
--------------------------------------------------------------------------
             ADD TO VISUAL STUDIO TOOLBOX INSTRUCTIONS
--------------------------------------------------------------------------

The following steps are required to manually install the controls into 
your Visual Studio or Visual Web Developer Express Toolbox. 
		
	1.  Open Visual Studio or Visual Web Developer Express.

	2.  Open an existing web site or create a new web site project.
	
	3.  Open or create a new .aspx page.

	4.  Open the ToolBox panel, typically located on the left side in a 
	    fly-out panel (Ctrl + Alt + x).

	5.  Create a new "Coolite Toolkit" Tab, by...
		  a. Right-Click in the ToolBox area.
		  b. Select "Add Tab".
		  c. Enter "Coolite".

	6.  Inside the "Coolite Toolkit" tab, Right-Click and select 
	    "Choose Items...".

	7.  Under the ".NET Framework Components" Tab select the "Browse" 
	    button.

	8.  Navigate to and select the Coolite.Ext.Web.dll file, choose open.
			
          NOTE: If the automatic installer has been run previously, the 
                Coolite.Ext.Web.dll can typically be found in the 
                following location:

                C:\Program Files\Coolite\Coolite Toolkit - Version 0.7.0\

	9.  The component items should now be added to the list and 
	    pre-checked. You can confirm by sorting the list by "Namespace" 
	    and scrolling to "Coolite.Ext.Web"

	10. Click "OK". The icons should be added to your ToolBox. You should 
	    now be able to drag/drop a Coolite component onto your WebForm.
	
	11. Enjoy.

--------------------------------------------------------------------------
                   Version 0.7.0 BREAKING CHANGES
--------------------------------------------------------------------------

1.	Renamed <Content> to <Body>, see 
	http://coolite.com/forums/Topic3059-7-1.aspx
	
2.	The .AutoLoad property has been enhanced to now require a LoadConfig 
	object, see http://www.coolite.com/forums/Topic5610-7-1.aspx 

	Example (Old)

	<ext:Panel 
		ID="Panel1" 
		runat="server" 
		Title="Parent" 
		Height="200"
		AutoLoad="Child.aspx"
		/>


	Example (New)

	<ext:Panel 
		ID="Panel1" 
		runat="server" 
		Title="Parent" 
		Height="200">
		<AutoLoad Url="Child.aspx" />
	</ext:Panel>


	The change also affects the .AutoLoadIFrame property.

	Example(Old)

	<ext:Panel 
		ID="Panel1" 
		runat="server" 
		Title="Parent" 
		Height="200"
		AutoLoadIFrame="http://www.google.com/"
		/>


	Example (New)

	<ext:Panel 
		ID="Panel1" 
		runat="server" 
		Title="Parent" 
		Height="200">
		<AutoLoad Url="http://www.google.com/" Mode="IFrame" />
	</ext:Panel>
	
3.  The <ext:ComboBox> OnItemChange event/property has been renamed to 
	OnValueChanged.

	Other than the renaming, the OnValueChanged property remains pretty 
	much untouched. As before, the event will fire when the ComboBox 
	losses focus (onBlur) if the value has changed. This functions very 
	similar to the "OnTextChanged" event of the <asp:TextBox>.

	Example (Old)

	<script runat="server">
		protected void ComboBox1_Changed(object sender, EventArgs e)
		{
			// something here...
		}
	</script>
	    
	<ext:ComboBox 
		ID="ComboBox1"
		runat="server"
		Width="200"
		AutoPostBack="true"
		OnItemChanged="ComboBox1_Changed"
		/>


	Example (New)

	<script runat="server">
		protected void ComboBox1_Changed(object sender, EventArgs e)
		{
			// something here...
		}
	</script>
	    
	<ext:ComboBox 
		ID="ComboBox1"  
		runat="server"
		Width="200"
		AutoPostBack="true"
		OnValueChanged="ComboBox1_Changed"
		/>
		
4.	The <UserParams> property of an AjaxEvent was renamed to 
	<ExtraParams>.

5.	The AjaxRespone.MakeAnswer() Method was renamed to 
	AjaxResponse.Write(). See items #3 and #4 below as well. 
	
	With all revisions combined, AjaxResponse.Write() is now 
	Response.Write().		

6.	The AjaxEvent EnableViewState (boolean) property was changed to 
	ViewStateMode (enum). Possible values include:
		a. Default
		b. Exclude
		c. Include

	If the AjaxEvent Type="Submit", the ViewState is updated on the 
	server-side, although by default this new ViewState is not returned 
	back to the client in the Response. If you require ViewState to be 
	persisted between AjaxEvents, please set ViewStateMode="Include".

	Example

	<ext:Button ID="Button1" runat="server" Text="Click Me">
		<AjaxEvents>
			<Click OnEvent="Button1_Click" ViewStateMode="Include" />
		</AjaxEvents>
	</ext:Button>


	The ViewStateMode can also be set at the Page level by setting 
	AjaxViewStateMode="Include" on the ScriptManager.

	Example

	<ext:ScriptManager 
		ID="ScriptManager1" runat="server" AjaxViewStateMode="Include" />


	The AjaxViewStateMode property can be set at the Session level.

	Example

	Session["Coolite.AjaxViewStateMode"]


	The AjaxViewStateMode can be set at the Application level.

	Example

	Application["Coolite.AjaxViewStateMode"]


	The AjaxViewStateMode can also be set in Application wide from within 
	the web.config.

	Example

	<?xml version="1.0"?>
	<configuration>
	  <configSections>
		<section 
			name="coolite" 
			type="Coolite.Web.UI.GlobalConfig"
			requirePermission="false" 
			/>
	  </configSections>
	  <coolite ajaxViewStateMode="Include" />
	</configuration>
	
7.	The previous "AjaxResponse" class renamed to "Response". 
	Functionality unchanged.

8.	The previous "ResponseObject" class renamed to "AjaxResponse".

9.	The <ext:Store> BeforeAjaxPostBackEventArgs renamed to 
	BeforeAjaxEventArgs.

10.	The <ext:Store> AfterAjaxPostBackEventArgs renamed to 
	AfterAjaxEventArgs.	
	
	
--------------------------------------------------------------------------
                         SAMPLE WEB.CONFIG
--------------------------------------------------------------------------

<?xml version="1.0"?>
<configuration>
  <configSections>
    <section name="coolite" type="Coolite.Web.UI.GlobalConfig" requirePermission="false" />
  </configSections>
  
  <!--  
      COOLITE GLOBAL CONFIGURATION PROPERTIES
      
      ajaxEventUrl : string
          The url to request for all AjaxEvents.
          Default is "".
                      
      ajaxMethodProxy : ClientProxy
          Specifies whether server-side Methods marked with the [AjaxMethod] attribute will output configuration script to the client. 
          If false, the AjaxMethods can still be called, but the Method proxies are not automatically generated. 
          Specifies ajax method proxies creation. The Default value is to Create the proxy for each ajax method.
          Default is 'Default'. Options include [Default|Include|Ignore]
      
      ajaxViewStateMode : ViewStateMode
          Specifies whether the ViewState should be returned and updated on the client during an AjaxEvent. 
          The Default value is to Exclude the ViewState from the Response.
          Default is 'Default'. Options include [Default|Exclude|Include]

      cleanResourceUrl : boolean
          The Coolite controls can clean up the autogenerate WebResource Url so they look presentable.        
          Default is 'true'. Options include [true|false]

      clientInitAjaxMethods : boolean
          Specifies whether server-side Methods marked with the [AjaxMethod] attribute will output configuration script to the client. 
          If false, the AjaxMethods can still be called, but the Method proxies are not automatically generated. 
          Default is 'false'. Options include [true|false]
          
      gzip : boolean
          Whether to automatically render scripts with gzip compression.        
          Only works when renderScripts="Embedded" and/or renderStyles="Embedded".       
          Default is true. Options include [true|false]

      scriptAdapter : string
          Gets or Sets the current script Adapter.     
          Default is "Ext". Options include [Ext|jQuery|Prototype|YUI]

      renderScripts : ResourceLocationType
          Whether to have the coolite controls output the required JavaScript includes or not.       
          Gives developer option of manually including required <script> files.        
          Default is Embedded. Options include [Embedded|File|None] 

      renderStyles : ResourceLocationType
          Whether to have the coolite controls output the required StyleSheet includes or not.       
          Gives developer option of manually including required <link> or <style> files.       
          Default is Embedded. Options include [Embedded|File|None]

      resourcePath : string
          Gets the prefix of the Url path to the base ~/Coolite/ folder containing the resources files for this project. 
          The path can be Absolute or Relative.

      scriptMode : ScriptMode
          Whether to include the Release (condensed) or Debug (with inline documentation) Ext JavaScript files.       
          Default is "Release". Options include [Release|Debug]
         
      sourceFormatting : boolean
          Specifies whether the scripts rendered to the page should be formatted. 'True' = formatting, 'False' = minified/compressed. 
          Default is 'false'. Options include [true|false]
      
      stateProvider : StateProvider
          Gets or Sets the current script Adapter.
          Default is 'PostBack'. Options include [PostBack|Cookie|None]
          
      theme : Theme
          Which embedded theme to use.       
          Default is "Default". Options include [Default|Gray|Slate]
          
      quickTips : boolean
          Specifies whether to render the QuickTips. Provides attractive and customizable tooltips for any element.
          Default is 'true'. Options include [true|false]
  -->

  <coolite theme="Default" />

  
  <!-- 
      The following system.web section is only requited for running ASP.NET AJAX under Internet
      Information Services 6.0 (or earlier).  This section is not necessary for IIS 7.0 or later.
  -->
  <system.web>
	  <httpHandlers>
      <add path="*/coolite.axd" verb="*" type="Coolite.Ext.Web.ResourceManager" validate="false" />
    </httpHandlers>
	  <httpModules>
		  <add name="AjaxRequestModule" type="Coolite.Ext.Web.AjaxRequestModule, Coolite.Ext.Web" />
	  </httpModules>
  </system.web>
  
  
	<!-- 
      The system.webServer section is required for running ASP.NET AJAX under Internet Information Services 7.0.
      It is not necessary for previous version of IIS.
  -->
	<system.webServer>
		<validation validateIntegratedModeConfiguration="false"/>
		<modules>
			<add name="AjaxRequestModule" preCondition="managedHandler" type="Coolite.Ext.Web.AjaxRequestModule, Coolite.Ext.Web" />
		</modules>
		<handlers>
			<add name="AjaxRequestHandler" verb="*" path="*/coolite.axd" preCondition="integratedMode" type="Coolite.Ext.Web.ResourceManager"/>
		</handlers>
	</system.webServer>
</configuration>

	
--------------------------------------------------------------------------
                               CREDITS
--------------------------------------------------------------------------
	
1.  FamFamFam Icons provided by Mark James 
	http://www.famfamfam.com/lab/icons/silk/
	
	See \Build\Resources\Coolite\icons\readme.txt for more information.

--------------------------------------------------------------------------
                               
--------------------------------------------------------------------------
	
        Copyright 2006-2008 Coolite Inc., All rights reserved.
                  
                             Coolite Inc.
                        208, 10113 104 Street
                   Edmonton, Alberta, Canada T5J 1A1
                           +1(888)775-5888
                           www.coolite.com
                           info@coolite.com