/*
 * Ext JS Library 2.2
 * Copyright(c) 2006-2008, Ext JS, LLC.
 * licensing@extjs.com
 * 
 * http://extjs.com/license
 */

Ext.app.Module = function(config){
    Ext.apply(this, config);
    Ext.app.Module.superclass.constructor.call(this);
    this.init();
}

Ext.extend(Ext.app.Module, Ext.util.Observable, {
    init: function() {
        if (!Ext.isEmpty(this.launcher) && !Ext.isEmpty(this.windowID)) {
            this.launcher.on("click", this.createWindow, this);
        }
    },
    createWindow: function() {
        if (Ext.isEmpty(this.windowID)) {
            return;
        }

        var desktop = this.app.getDesktop();
        var win = desktop.getWindow(this.windowID);
        if (!win) {
            var winCmp = Ext.getCmp(this.windowID);
            if(Ext.isEmpty(winCmp)){
                return false;
            }
            win = desktop.tuneDesktopWindow(winCmp);
        }
        win.show();
        return true;
    }
});
if(typeof Sys!=="undefined"){Sys.Application.notifyScriptLoaded();}