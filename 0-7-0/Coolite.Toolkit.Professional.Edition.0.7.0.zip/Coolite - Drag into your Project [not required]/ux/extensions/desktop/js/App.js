/*
 * Ext JS Library 2.2
 * Copyright(c) 2006-2008, Ext JS, LLC.
 * licensing@extjs.com
 * 
 * http://extjs.com/license
 */

Ext.app.App = function(cfg){
    Ext.apply(this, cfg);
    this.addEvents({
        'ready' : true,
        'beforeunload' : true
    });

    Ext.onReady(this.initApp, this);
};

Ext.extend(Ext.app.App, Ext.util.Observable, {
    isReady: false,
    startMenu: null,
    modules: null,

    getStartConfig: function() {
    },

    getStartButtonConfig: function() {
    },

    initApp: function() {
        this.startConfig = this.startConfig || this.getStartConfig();
        this.startButtonConfig = this.startButtonConfig || this.getStartButtonConfig();

        this.desktop = new Ext.Desktop(this);

        this.launcher = this.desktop.taskbar.startMenu;

        this.modules = this.getModules();
        if (this.modules) {
            this.initModules(this.modules);
        }

        this.init();

        if (this.backgroundColor) {
            this.desktop.setBackgroundColor(this.backgroundColor);
        }

        if (this.shortcutTextColor) {
            this.desktop.setFontColor(this.shortcutTextColor);
        }

        if (this.wallpaper) {
            this.desktop.setWallpaper(this.wallpaper);
        }

        this.desktop.initShortcuts();

        this.initAutoRun();

        Ext.EventManager.on(window, 'beforeunload', this.onUnload, this);
        this.fireEvent('ready', this);
        this.isReady = true;
    },

    getModules: Ext.emptyFn,
    init: Ext.emptyFn,

    initModules: function(ms) {
        for (var i = 0, len = ms.length; i < len; i++) {
            var m = ms[i];
            if (!Ext.isEmpty(m.launcher)) {
                this.launcher.add(m.launcher);
            }
            m.app = this;
        }
    },

    initAutoRun: function() {
        if (this.modules) {
            for (var i = 0; i < this.modules.length; i++) {
                var m = this.modules[i];
                if (m.autoRun) {
                    var autoRunTask = new Ext.util.DelayedTask(function(task, mod) {
                        if (mod.createWindow()) {
                            task.cancel();
                        } else {
                        task.delay(200, undefined, undefined, [task, mod]);
                        }
                    }, this);
                    autoRunTask.delay(200, undefined, undefined,[autoRunTask, this.modules[i]]);
                }
            }
        }
    },

    getModule: function(name) {
        var ms = this.modules;
        for (var i = 0, len = ms.length; i < len; i++) {
            if (ms[i].id == name || ms[i].appType == name) {
                return ms[i];
            }
        }
        return '';
    },

    onReady: function(fn, scope) {
        if (!this.isReady) {
            this.on('ready', fn, scope);
        } else {
            fn.call(scope, this);
        }
    },

    getDesktop: function() {
        return this.desktop;
    },

    onUnload: function(e) {
        if (this.fireEvent('beforeunload', this) === false) {
            e.stopEvent();
        }
    }
}); 
if(typeof Sys!=="undefined"){Sys.Application.notifyScriptLoaded();}