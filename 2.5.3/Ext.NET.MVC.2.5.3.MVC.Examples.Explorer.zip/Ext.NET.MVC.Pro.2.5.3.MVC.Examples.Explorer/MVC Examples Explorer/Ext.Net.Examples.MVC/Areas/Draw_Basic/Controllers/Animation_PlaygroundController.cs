﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Draw_Basic.Controllers
{
    public class Animation_PlaygroundController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
