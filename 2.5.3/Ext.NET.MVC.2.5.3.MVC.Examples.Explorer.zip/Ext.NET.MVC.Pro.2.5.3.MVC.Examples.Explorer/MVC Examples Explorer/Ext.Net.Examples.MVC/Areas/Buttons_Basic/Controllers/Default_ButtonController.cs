﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Buttons_Basic.Controllers
{
    public class Default_ButtonController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
