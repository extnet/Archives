﻿Project      : Ext.NET.Utilties
Version      : 2.4.0
Last Updated : 2013-12-17

--------------------------------------------------------------------------
DESCRIPTION
--------------------------------------------------------------------------

A .NET Utility Class Library for Ext.NET (http://www.ext.net/)

Install using NuGet (http://nuget.org/packages/Ext.NET.Utilities).

    Install-Package Ext.NET.Utilities


--------------------------------------------------------------------------
RELEASE HISTORY
--------------------------------------------------------------------------

2013-12-17 (geoffreymcgill)

- Release v2.4.0

2013-10-04 (geoffreymcgill)

- Release v2.3.0

2013-04-16 (geoffreymcgill)

- Release v2.2.1


2013-03-20 (geoffreymcgill)

- Release v2.2.0


2012-11-19 (geoffreymcgill)

- Release v2.1.0


2012-05-24 (geoffreymcgill)

- Release v2.0.1


2012-03-05 (geoffreymcgill)

- Release v2.0.0