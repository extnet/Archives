namespace Ext.Net.Examples.SimpleTasks
{
    partial class SimpleTasksDataContext
    {
    }
}
