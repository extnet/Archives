﻿// @source data/GridEditor.js
//Ext.grid.GridEditor.override({
//    initComponent : function () {
//        this.on("canceledit", this.field.reset, this.field);
//        this.on("complete", this.field.reset, this.field);
//        Ext.grid.GridEditor.superclass.initComponent.call(this);
//    }
//});