
// @source data/ArrayReader.js

Ext.data.ArrayReader.override({
    isArrayReader : true
});