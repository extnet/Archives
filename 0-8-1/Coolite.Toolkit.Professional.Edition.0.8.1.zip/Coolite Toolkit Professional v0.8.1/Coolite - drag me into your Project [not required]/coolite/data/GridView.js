
// @source data/GridView.js

Ext.grid.GridView.prototype.initEvents = Ext.grid.GridView.prototype.initEvents.createSequence(function () {
    this.addEvents("afterRender");
});

Ext.grid.GridView.prototype.afterRender = Ext.grid.GridView.prototype.afterRender.createSequence(function () {
    this.fireEvent("afterRender", this);
});

Ext.grid.GridView.override({
    getCell : function (row, col) {
        var tds = this.getRow(row).getElementsByTagName("td"),
            ind = -1;
            
        if (tds) {
            for (var i = 0; i < tds.length; i++) {
                if (Ext.fly(tds[i]).hasClass("x-grid3-col x-grid3-cell")) {
                    ind++;
                    
                    if (ind == col) {
                        return tds[i];
                    }
                }
            }
        }
        return tds;
    }
});