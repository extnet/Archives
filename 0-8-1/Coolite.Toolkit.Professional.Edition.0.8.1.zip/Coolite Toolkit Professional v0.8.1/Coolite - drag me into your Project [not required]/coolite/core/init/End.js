
// @source core/init/End.js


if (!Ext.isIE6) {
    if (Ext.isIE) {
        Ext.util.CSS.createStyleSheet(".x-btn button{width:100%;}");
    }
    Ext.util.CSS.createStyleSheet(".x-form-radio-group .x-panel-body,.x-form-check-group .x-panel-body{background-color:transparent;} .x-form-cb-label-nowrap{white-space:nowrap;} .x-label-icon{width:16px;height:16px; margin-left:3px; margin-right:3px; vertical-align:middle;border:0px !important;} .x-label-value{vertical-align:middle;}");
}

if (Ext.isIE8) {
    Ext.util.CSS.createStyleSheet(".ext-ie8 .x-form-text{margin: 0px 0px;}");
}    

Coolite.Ext.setTheme = function (url) {
    Ext.util.CSS.swapStyleSheet("ext-theme", url);
};

Ext.util.CSS.createStyleSheet(".x-tree-node .x-tree-node-inline-icon{background:transparent;height:16px !important;} .ext-ie .x-small-editor .x-form-trigger{top:-1px;} .ext-ie .x-small-editor .x-form-text{top: 0px;} .x-field-note { clear: both; font-size: 12px; color: gray;} .x-field-multi { float: left; padding-right: 3px; position: relative;} .x-inline-toolbar{padding:0px !important; border:0px !important; background: none !important;}");         

if (typeof Sys !== "undefined") { 
    Sys.Application.notifyScriptLoaded();
}