
// @source core/form/Checkbox.js

Ext.form.Checkbox.prototype.onRender = Ext.form.Checkbox.prototype.onRender.createSequence(function (ct, position) {
    if (!Ext.isEmpty(this.cls)) {
        this.wrap.addClass(this.cls);
    }
});

Ext.form.Checkbox.override({
    setBoxLabel : function (label) {
        if (this.labelEl) {
            this.labelEl.dom.innerHTML = label;
        } else {
            this.boxLabel = label;
            
            this.labelEl = this.innerWrap.createChild({
                tag     : "label",
                htmlFor : this.el.id,
                cls     : "x-form-cb-label",
                html    : this.boxLabel
            });
        }
    }
});