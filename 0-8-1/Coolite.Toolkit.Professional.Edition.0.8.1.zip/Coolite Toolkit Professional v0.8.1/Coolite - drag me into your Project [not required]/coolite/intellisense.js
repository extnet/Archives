/// <reference name="Coolite.Ext.Web.Build.Resources.Coolite.extjs.adapter.ext.ext-base.js" assembly="Coolite.Ext.Web" />
/// <reference name="Coolite.Ext.Web.Build.Resources.Coolite.extjs.ext-all-debug.js" assembly="Coolite.Ext.Web" />

if (typeof Sys !== "undefined") {
    Sys.Application.notifyScriptLoaded();
}