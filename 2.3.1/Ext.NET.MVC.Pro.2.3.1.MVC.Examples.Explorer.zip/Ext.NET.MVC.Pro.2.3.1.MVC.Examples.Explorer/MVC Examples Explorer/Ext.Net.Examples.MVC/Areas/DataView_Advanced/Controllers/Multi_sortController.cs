﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.DataView_Advanced.Controllers
{
    public class Multi_sortController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
