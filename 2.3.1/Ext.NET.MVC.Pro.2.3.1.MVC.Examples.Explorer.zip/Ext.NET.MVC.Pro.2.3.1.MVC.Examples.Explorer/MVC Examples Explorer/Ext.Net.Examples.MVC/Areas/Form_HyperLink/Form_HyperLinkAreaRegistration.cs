﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Form_HyperLink
{
	public class Form_HyperLinkAreaRegistration : AreaRegistration
	{
		public override string AreaName
		{
			get
			{
				return "Form_HyperLink";
			}
		}

		public override void RegisterArea(AreaRegistrationContext context)
		{
			context.MapRoute(
				"Form_HyperLink_default",
				"Form_HyperLink/{controller}/{action}/{id}",
				new { action = "Index", id = UrlParameter.Optional }
			);
		}
	}
}
