﻿namespace Ext.Net.MVC.Examples.Areas.PropertyGrid_Basic.Models
{
	public class StoreValueModel
	{
		public string name { get;set; }

		public string value { get;set; }
	}
}