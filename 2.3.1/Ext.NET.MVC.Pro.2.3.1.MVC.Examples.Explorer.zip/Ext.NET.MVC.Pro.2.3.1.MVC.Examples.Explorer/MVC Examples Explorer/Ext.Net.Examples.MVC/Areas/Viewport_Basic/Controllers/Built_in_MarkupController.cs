﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Viewport_Basic.Controllers
{
    public class Built_in_MarkupController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

    }
}
