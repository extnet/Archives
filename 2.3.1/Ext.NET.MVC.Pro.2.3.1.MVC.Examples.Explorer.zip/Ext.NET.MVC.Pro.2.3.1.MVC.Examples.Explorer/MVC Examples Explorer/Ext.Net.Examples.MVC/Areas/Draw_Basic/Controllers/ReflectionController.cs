﻿using System.Web.Mvc;

namespace Ext.Net.MVC.Examples.Areas.Draw_Basic.Controllers
{
    public class ReflectionController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
